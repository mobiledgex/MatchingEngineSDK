//
//  SwiftLocationTests.swift
//  Daniele Margutti
//
//  Created by Daniele Margutti on 27/10/2017.
//  Copyright © 2017 Daniele Margutti. All rights reserved.
//

import Foundation
import XCTest
import SwiftLocation

class SwiftLocationTests: XCTestCase {
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        //// XCTAssertEqual(SwiftLocation().text, "Hello, World!")
    }
    
    static var allTests = [
        ("testExample", testExample),
    ]
}
