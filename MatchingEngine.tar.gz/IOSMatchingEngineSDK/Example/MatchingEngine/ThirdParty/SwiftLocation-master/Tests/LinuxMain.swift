import XCTest
@testable import SwiftLocationTests

XCTMain([
    testCase(SwiftLocationTests.allTests),
])
