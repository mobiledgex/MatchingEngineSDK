## 0.4.0 Beta (2017-03-12)

##### Enhancements

## 0.4.0 Beta

* Adds a progress callback to track status

## 0.3.0 Beta
* Pod is now called via block syntax

* Enhancement to image generation that resolves orientation issue  
